package Interface;

public interface Perilaku {
    public abstract void Cetak();
    public abstract void CetakNama();
}
